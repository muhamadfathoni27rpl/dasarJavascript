const a = 4 , r = 3 , u10 = 0 , n = 10

//Setup Variabel
var r10 = (r**n - 1),
    r1 = (r-1)
console.log("Diketahui");
console.log("* suku pertama (a) = "+a);
console.log("* rasio (r) = "+r);
console.log("* jumlah 10 suku pertama (n) = "+n);
console.log("Rumus >> Sn = a x (r^n -1) / (r - 1)");
console.log("\x1b[33m","Jawaban = "+a*(r10/r1));
// [c] Script By : mhmdfathoni_
// root@panic:~#