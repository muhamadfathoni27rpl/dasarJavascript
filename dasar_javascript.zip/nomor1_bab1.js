const p = 20.5 , l = 30 , harga = 1500000
var total = (p*l)*harga
console.log("Tanah yang dipesan adalah "+p +" x "+ l);
console.log("harga tanah = Rp."+ total + " , Pajak 15% = Rp."+ (total * 0.15));
console.log("\x1b[33m","Total Rp."+(total + (total * 0.15)));
// [c] Script By : mhmdfathoni_
// root@panic:~#