let barang = [
    {nama : "beras", harga : 10000 , jumlah : 5},
    {nama : "gula", harga : 14000 , jumlah : 5},
    {nama : "telur", harga : 20000 , jumlah : 2},
    {nama : "minyak goreng", harga : 9000 , jumlah : 10}
]
var total = 0
// console.log(JSON.stringify(barang[1]));
for (var i = 0 ; i < barang.length ; i++ ){
    var x = barang[i] ,totalHargaIni = (x.harga * x.jumlah) 
    console.log("===============================");
    console.log("Total dari barang "+ x.nama);
    console.log(">>> Harga : Rp."+x.harga + " , Jumlah : "+x.jumlah);
    console.log("Total "+ totalHargaIni);    
    console.log("");    
    total += totalHargaIni
}
console.log("\x1b[33m","TOTAL Belanja Keseluruhan : Rp." + total);
// [c] Script By : mhmdfathoni_
// root@panic:~#