// // ========== ARRAY ==========
// //############################

// // 1 get data array
// let jurusan = ["Rekayasa Perangkat Lunak","Teknik Komputer dan Jaringan"]
// let tingkatan_kelas = [10,11,12]
// let siswa = [    
//     {nama: "yaya",jurusan: "RPL"},
//     {nama: "Ying",jurusan: "TKJ"},
//     {nama: "gopal",jurusan: "RPL"}
// ]
// console.log("Jumlah Element Array = "+ jurusan.length);
// console.log("Jumlah Element Array Tingkatan Kelas"+ tingkatan_kelas.length);
// console.log("Jumlah Element Array Siswa = "+ siswa.length)








// //2 menambah data array
// let kota = ["Malang","Surabaya","Tulungagung"]
// console.log("Isis array kota");
// console.log(kota);
// console.log("Jumlah data = "+kota.length);
// console.log("-------------------------------");
// kota.push("Banyuwangi")
// console.log(kota);
// console.log("Jumlah data saat ini = "+kota.length);








//3 menambah data array
// let barang =[
//     {nama : "Rinso",harga : 5000},
//     {nama : "Moonlight" , harga : 4000}
// ]
// console.log("isi arrray barang");
// console.log(barang);
// console.log("Jumlah data :"+barang.length);
// barang.push({nama : "Mloto",harga : 1000})
// console.log("update terbaru");
// console.log(barang);
// console.log("Jumlah data saat ini = "+barang.length);






// // //4 menghapus data array
// let Data = ["Ana","Sulaiman","Putri","Gtaot","Adit","Gico"]
// console.log(Data);
// console.log("Jumlah Data Saat ini = "+Data.length)
// console.log("Sesudah di Hapus");
// Data.splice(2,1)
// console.log(Data);
// console.log("Jumlah Data Saat ini = "+Data.length);









// //5 menampilkan data array objek
// let siswa =[
//     { nama_depan: "Jack", nama_belakang: "Ma" } , 
//     { nama_depan : "Johnny", nama_belakang: "English" },
//     { nama_depan: "John", nama_belakang: "Cena"} 
// ]
// siswa. map( 
//     (sis, index) => { 
//     console. log(sis.nama_depan + "" + sis. nama_belakang); 
//     }
// )







// // ========== OPERATOR ==========
// //###############################

// //1 aritmatika
// let a = 2 , b = 5 , c = "10"
// console.log("a + b "+ (a + b));
// console.log("a + c "+(a+c));
// console.log("a - b "+(a-b));
// console.log("a * b "+(b*a));
// console.log("b / a "+(b/a));
// console.log("b % a "+(b%a));
// console.log("b ** a "+(b**a));









// //2 penugasan
// let a = 5 , b = 10 , c = "5"
// console.log("a == c "+(a == c));
// console.log("a === c "+(a === c));
// console.log("a != c "+(a != c));
// console.log("a !== c "+(a !== c));
// console.log("a > b "+(a > b));
// console.log("a >= b "+(a >= b));
// console.log("a < b "+(a < b));
// console.log("a <= b "+(a <= b));







// // ========== Percabangan ==========
// //##################################

// //1 if
// if (2020 %4 == 0){console.log("Adalah Tahun Kabisat");}


// //2 if else
// if(2020 % 4 == 0){console.log(2020 +" adalah tahun kabisat");}
// else{console.log(2020 +" Bukan Tahun Kabisat");}

// //if else if else
// let x = 80
// if(x > 80){console.log("exelent");}
// else if(x <= 80 && x >70){
//     console.log("good");
// }
// else if(x <= 70 && x > 60){
//     console.log("not bad");
// }
// else {console.log("feeling gud men");}







// // ========== Perulangan ==========
// //#################################

// //1 for loop
// for (let i = 0; i <= 10; i++) {
//     console.log("perulangan ke"+i);
// }

// //2 for/in loop
// let siswa={
//     nama : "Toni",
//     gender: "laki",
//     jurusan : "RPL",
//     usia : "20",
//     alamat : "Ngantru"
// }
// for(x in siswa){
//     console.log(x);
// }

// //3 for/of loop
// let hokage = ["Hashirama","Tobirama","Hiruzen","Minato","Tsunade","Kakashi","Naruto"]
// for (x of hokage){
//     console.log(x);
// }

// //while loop
// let laptop = ["asus","acer","hp"]
// let i = 0
// while(laptop[i]){
//     console.log(laptop[i]);
//     i++
// }



// //Do While
// let hp = ["samsung" , "xiaomi" , "apel"]
// let i = 0
// do{console.log(hp[i]); i++}
// while(hp[i])










// // ========== Function ==========
// //###############################
// luasLingkaran = (r) =>{
//     return 3.14 * (r**2)
// }
// console.log("Luas lingkaran r=10"+luasLingkaran(10));









// // ========== Class ============
// //###############################

// //1
// class PersegiPanjang {
//     constructor(panjang , lebar) {        
//       this.panjang = panjang
//       this.lebar = lebar      
//     }    
//     luas() {
//         let p = this.panjang
//         let l = this.lebar
//         return p*l
//     }
//     keliling() {
//         let p = this.panjang
//         let l = this.lebar
//         return 2 * (p+l)
//     }
//   }
// var gas = new PersegiPanjang(10,50);
// console.log(gas.luas());
// console.log(gas.keliling());

// //2
// //PEWARISAN || Inheritance 
class PersegiPanjang{
    constructor(panjang , lebar){
        this.panjang = panjang
        this.lebar = lebar}
    luas(){
        let p = this.panjang
        let l = this.lebar
        return p*l
    }
    keliling(){
        let p = this.panjang
        let l = this.lebar
        return 2*(p+l)}
}
class Balok extends PersegiPanjang{
    constructor(panjang,lebar,tinggi){
        super(panjang,lebar)
        this.tinggi = tinggi}
    luas(){
        let p = this.panjang
        let l = this.lebar
        let t = this.tinggi
        return (2*p*l)+(2*p*t)+(2*t*l)}
    volume(){
        return this.panjang * this.lebar * this.tinggi}
}
var gas = new Balok(10,5,2)
console.log(gas.luas());
console.log(gas.volume());