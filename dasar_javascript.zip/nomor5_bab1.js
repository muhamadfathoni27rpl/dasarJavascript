//Setup Class
class Tabung{
    constructor(jari_jari,tinggi){
        this.jari_jari = jari_jari
        this.tinggi = tinggi
    }
    luasPermukaan(){
        //rumus 2 (π r 2 )+ 2 π r t
        let v = 3.14
        let r = this.jari_jari / 2
        let t = this.tinggi
        return 2 * (v*r*2) + 2*v*r*t
    }
    luasSelimut(){
        //rumus 2πrt
        let v = 3.14
        let r = this.jari_jari / 2
        let t = this.tinggi
        return 2*v*r*t
    }
    volume(){
        let v = 3.14
        let r = this.jari_jari / 2
        let t = this.tinggi
        //rumus π x r^2 x t
        return v * r**2 *t
    }
}
class Kerucut{
    constructor(jari_jari , tinggi){
        this.jari_jari = jari_jari
        this.tinggi = tinggi
    }
    luasSelimut(){
        //rumus π r akar{ t^2 + r^2}
        let v = 3.14
        let r = this.jari_jari / 2
        let t = this.tinggi
        return v * r * Math.sqrt(t**2 + r**2)
    }
    luasPermukaan(){
        // rumus π r (r + akar{t^2 + r^2})
        let v = 3.14
        let r = this.jari_jari / 2
        let t = this.tinggi
        return v * r * (r + Math.sqrt(t**2 + r**2))
    }
    volume(){
        // rumus 1/3 π r^2 t        
        let v = 3.14
        let r = this.jari_jari / 2
        let t = this.tinggi
        return 1 / 3 * v * r**2 * t        
    }
}
class Bola{
    constructor(jari_jari){
        this.jari_jari = jari_jari
    }
    luasPermukaan(){
        // rumus 4 π r^2
        let r = this.jari_jari / 2
        return 4 * 3.14 * r**2
        // return r**2
    }
    volume(){
        // rumus 4/3 π r^3
        let r = this.jari_jari / 2
        return 4/3 * 3.14 * r**3
    }
}

//Main
var tabung  = new Tabung(15,50)
var kerucut = new Kerucut(20,40)
var bola    = new Bola(30)
console.log("===== Tabung =====");
console.log("=> input r = 7.5 cm , t = 50 cm");
console.log("Volume         : "+ tabung.volume()+" cm");
console.log("Luas Permukaan : "+ tabung.luasPermukaan()+" cm");
console.log("Luas Selimut   : "+ tabung.luasSelimut()+" cm");
console.log("===== Kerucut =====");
console.log("=> input r = 10 cm , t = 40 cm");
console.log("Volume         : "+ kerucut.volume()+" cm");
console.log("Luas Permukaan : "+ kerucut.luasPermukaan()+" cm");
console.log("Luas Selimut   : "+ kerucut.luasSelimut()+" cm");
console.log("===== Bola =====");
console.log("=> input r = 15");
console.log("Volume         : "+ bola.volume()+" cm");
console.log("Luas Permukaan : "+ bola.luasPermukaan()+" cm");
console.log("<><><><><><><><><><><><><><>");
// [c] Script By : mhmdfathoni_
// root@panic:~#