const t = 170/100 , b = 90
var nilai = b/t**2
console.log("Nilai  : " + nilai);
if(nilai < 18.5){
    console.log("\x1b[33m","Kekurangan Berat Badan");
}else if(nilai >= 18.5 && nilai <= 24.9){
    console.log("Normal");
}else if(nilai >= 25.0 && nilai <= 29.9){
    console.log("\x1b[33m","Kelebihan Berat Badan");
}else{
    console.log("\x1b[33m","Kegemukan (Obesitas)");
}
// [c] Script By : mhmdfathoni_
// root@panic:~#